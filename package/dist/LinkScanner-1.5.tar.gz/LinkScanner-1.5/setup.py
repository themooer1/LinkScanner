from setuptools import setup

setup(name="LinkScanner",description="Follow links from website to website.",url="https://github.com/themooer1/LinkScanner",author="Eugene Wolffe",author_email="fluffy1781@gmail.com",license="GPL",packages=["LinkScanner"],install_requires=['requests'],version="1.05")
